---
layout: home
title: ホーム
---

# Auto Invest News

AIが毎日自動生成する投資ニュースをお届けします。

## 最新記事

<div class="home">
  {% for post in site.posts limit:10 %}
    <article class="post">
      <h2><a href="{{ post.url }}">{{ post.title }}</a></h2>
      <p class="post-meta">{{ post.date | date: "%Y年%m月%d日" }}</p>
      <div class="post-excerpt">
        {{ post.excerpt }}
      </div>
      <a href="{{ post.url }}">続きを読む →</a>
    </article>
  {% endfor %}
</div>