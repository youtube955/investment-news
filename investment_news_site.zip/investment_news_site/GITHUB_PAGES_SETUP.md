# 🚀 GitHub Pages 完全自動投稿システム - セットアップガイド

## ✨ このシステムの特徴

- 📝 **完全自動投稿** - GitHub Actionsで毎日自動実行
- 🌐 **無料ホスティング** - GitHub Pagesで完全無料
- 🔒 **管理画面不要** - GitHubリポジトリに直接コミット
- ⚡ **高速公開** - プッシュ後、数分で自動公開
- 📱 **レスポンシブ** - スマホ対応のきれいなデザイン

## 📋 必要なもの

1. **GitHubアカウント**（無料）
2. **Git**がインストールされたPC

## 🎯 セットアップ手順（10分）

### ステップ1: GitHubリポジトリを作成

1. [GitHub](https://github.com)にログイン
2. 右上の「+」→「New repository」をクリック
3. リポジトリ名を入力（例: `investment-news`）
4. 「Public」を選択（GitHub Pages は Public リポジトリで無料）
5. 「Create repository」をクリック

### ステップ2: ローカルにサイトファイルをコピー

```bash
# 生成されたサイトファイルをコピー
cp -r /home/user/investment_news_site ~/my-investment-site
cd ~/my-investment-site

# または、サーバーからダウンロード
```

### ステップ3: GitHubにプッシュ

```bash
cd ~/my-investment-site

# Gitリポジトリを初期化（既に実行済み）
git init
git branch -M main

# GitHubリポジトリを追加（YOUR_USERNAME と YOUR_REPO を置き換え）
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git

# 最初のコミット
git add .
git commit -m "Initial commit: Auto Invest News site"

# GitHubにプッシュ
git push -u origin main
```

### ステップ4: GitHub Pages を有効化

1. GitHubリポジトリのページで「Settings」タブをクリック
2. 左メニューから「Pages」を選択
3. **Source** を「Deploy from a branch」に設定
4. **Branch** を「main」、フォルダーを「/ (root)」に設定
5. 「Save」をクリック

**🎉 数分後、サイトが公開されます！**

URLは `https://YOUR_USERNAME.github.io/YOUR_REPO/` です。

### ステップ5: GitHub Actions の確認

1. リポジトリの「Actions」タブをクリック
2. 「Auto Post Market News」ワークフローが表示される
3. これが毎日自動実行されます

## ⏰ 自動投稿のスケジュール

`.github/workflows/auto_post.yml` で設定済み：

- **平日 朝9時（日本時間）** - 市場オープン前
- **平日 午後3:30（日本時間）** - 市場クローズ後

## 🧪 手動でテスト投稿

### ローカルで記事生成
```bash
cd /home/user
python github_pages_publisher.py --auto
```

### GitHubで手動実行
1. リポジトリの「Actions」タブ
2. 「Auto Post Market News」を選択
3. 「Run workflow」をクリック

## 📁 ファイル構造

```
investment_news_site/
├── _config.yml              # サイト設定
├── index.md                 # トップページ
├── about.md                 # Aboutページ
├── README.md                # 説明
├── .gitignore              # Git除外設定
│
├── _posts/                  # 記事フォルダ
│   └── YYYY-MM-DD-market-report.md  # 記事ファイル
│
└── .github/
    └── workflows/
        └── auto_post.yml    # 自動実行設定
```

## 🎨 サイトのカスタマイズ

### サイト名やタイトルを変更

`_config.yml` を編集：
```yaml
title: あなたのサイト名
description: あなたのサイトの説明
```

### デザインテーマを変更

`_config.yml` で theme を変更：
```yaml
theme: minima  # デフォルト
# または
theme: jekyll-theme-cayman
theme: jekyll-theme-slate
```

[利用可能なテーマ一覧](https://pages.github.com/themes/)

### 記事のカスタマイズ

`github_pages_publisher.py` の `generate_markdown_post()` 関数を編集

## 🔧 トラブルシューティング

### サイトが表示されない
- GitHub Pages の設定を確認
- リポジトリが Public になっているか確認
- 数分待ってから再読み込み

### GitHub Actions が実行されない
- リポジトリの Settings → Actions → General で「Allow all actions」を確認
- ワークフローファイルが正しくプッシュされているか確認

### 記事が生成されない
- Actions タブでエラーログを確認
- Python スクリプトが正しくコミットされているか確認

## 📊 運用後の管理

### 記事の確認
- サイトURL: `https://YOUR_USERNAME.github.io/YOUR_REPO/`
- GitHub: リポジトリの `_posts/` フォルダ

### ログの確認
- リポジトリの「Actions」タブ
- 各実行をクリックして詳細を表示

### 手動で記事追加
```bash
# _posts/ に新しい .md ファイルを作成
# ファイル名: YYYY-MM-DD-title.md

# コミット＆プッシュ
git add _posts/
git commit -m "Add new article"
git push
```

## 🌟 さらなる改善案

### Google Analytics 追加
`_config.yml` に追加：
```yaml
google_analytics: UA-XXXXXXXXX-X
```

### コメント機能追加
- Disqus
- utterances（GitHub Issues ベース）

### RSS フィード
自動生成されます：`/feed.xml`

### 独自ドメイン設定
1. ドメインを取得
2. DNS設定でCNAMEレコードを追加
3. リポジトリに `CNAME` ファイルを作成

## 💰 コスト

**完全無料！** 🎉

- GitHub Pages: 無料
- GitHub Actions: 月2,000分まで無料（十分すぎる）
- ドメイン: オプション（年間数百円〜）

## 📞 サポート

### 参考リンク
- [GitHub Pages ドキュメント](https://docs.github.com/ja/pages)
- [Jekyll ドキュメント](https://jekyllrb.com/docs/)
- [GitHub Actions ドキュメント](https://docs.github.com/ja/actions)

---

**🎊 セットアップお疲れ様でした！**

これで完全自動の投資ニュースサイトが完成です！
毎日自動で記事が投稿され、世界中からアクセス可能になります。

何か問題があれば、GitHubのIssuesでお気軽にお尋ねください。