#!/usr/bin/env python3
"""
GitHub Pages 自動投稿システム
GitHubリポジトリに記事をコミット→自動的にウェブサイトに公開
"""

import os
import json
import subprocess
from datetime import datetime
import yfinance as yf

class GitHubPagesPublisher:
    def __init__(self):
        self.repo_path = "/home/user/investment_news_site"
        self.posts_dir = os.path.join(self.repo_path, "_posts")
        
    def setup_github_pages_site(self):
        """GitHub Pagesサイトの初期セットアップ"""
        print("🚀 GitHub Pages サイトをセットアップ")
        
        # リポジトリディレクトリを作成
        os.makedirs(self.repo_path, exist_ok=True)
        os.makedirs(self.posts_dir, exist_ok=True)
        
        # _config.yml を作成
        config_content = """
title: Auto Invest News
description: AIが自動生成する投資ニュース
theme: minima
markdown: kramdown

# プラグイン
plugins:
  - jekyll-feed
  - jekyll-seo-tag

# サイト設定
lang: ja
timezone: Asia/Tokyo

# ナビゲーション
header_pages:
  - about.md
  - archive.md

# SNS
twitter_username: your_twitter
github_username: your_github
"""
        
        with open(os.path.join(self.repo_path, "_config.yml"), 'w', encoding='utf-8') as f:
            f.write(config_content.strip())
        
        # index.md を作成
        index_content = """---
layout: home
title: ホーム
---

# Auto Invest News

AIが毎日自動生成する投資ニュースをお届けします。

## 最新記事

<div class="home">
  {% for post in site.posts limit:10 %}
    <article class="post">
      <h2><a href="{{ post.url }}">{{ post.title }}</a></h2>
      <p class="post-meta">{{ post.date | date: "%Y年%m月%d日" }}</p>
      <div class="post-excerpt">
        {{ post.excerpt }}
      </div>
      <a href="{{ post.url }}">続きを読む →</a>
    </article>
  {% endfor %}
</div>
"""
        
        with open(os.path.join(self.repo_path, "index.md"), 'w', encoding='utf-8') as f:
            f.write(index_content.strip())
        
        # about.md を作成
        about_content = """---
layout: page
title: About
permalink: /about/
---

# Auto Invest News について

このサイトは、AIが市場データをリアルタイムで分析し、
毎日自動的に投資ニュース記事を生成・公開しています。

## 特徴

- 📊 リアルタイム市場データ分析
- 🤖 AI自動記事生成
- ⏰ 毎日自動更新
- 📈 日経平均、為替、米国株など

## 免責事項

本サイトの情報は情報提供を目的としており、投資助言ではありません。
投資判断は自己責任でお願いいたします。
"""
        
        with open(os.path.join(self.repo_path, "about.md"), 'w', encoding='utf-8') as f:
            f.write(about_content.strip())
        
        # .gitignore を作成
        gitignore_content = """
_site/
.sass-cache/
.jekyll-cache/
.jekyll-metadata
*.pyc
__pycache__/
"""
        
        with open(os.path.join(self.repo_path, ".gitignore"), 'w', encoding='utf-8') as f:
            f.write(gitignore_content.strip())
        
        # README.md を作成
        readme_content = """# Auto Invest News

AIが自動生成する投資ニュースサイト

## セットアップ

1. このリポジトリをGitHubにプッシュ
2. Settings → Pages → Source を "main" ブランチに設定
3. 自動的にサイトが公開されます

## 自動更新

GitHub Actionsで毎日自動的に記事を生成・公開します。

## ローカルでの確認

```bash
bundle exec jekyll serve
```

http://localhost:4000 でプレビュー
"""
        
        with open(os.path.join(self.repo_path, "README.md"), 'w', encoding='utf-8') as f:
            f.write(readme_content.strip())
        
        print("✅ サイト構造を作成しました")
        
    def get_market_data(self):
        """市場データ取得"""
        try:
            symbols = {
                '^N225': '日経平均株価',
                'USDJPY=X': 'ドル円為替',
                '^IXIC': 'ナスダック',
                '^GSPC': 'S&P500'
            }
            
            market_data = {}
            
            for symbol, name in symbols.items():
                try:
                    ticker = yf.Ticker(symbol)
                    hist = ticker.history(period='2d')
                    
                    if not hist.empty:
                        latest = hist.iloc[-1]
                        previous = hist.iloc[-2] if len(hist) >= 2 else latest
                        
                        change = latest['Close'] - previous['Close']
                        change_pct = (change / previous['Close']) * 100
                        
                        market_data[symbol] = {
                            'name': name,
                            'price': float(latest['Close']),
                            'change': float(change),
                            'change_pct': float(change_pct)
                        }
                except:
                    pass
            
            return market_data
        except:
            return {}
    
    def generate_markdown_post(self, market_data):
        """Markdown形式の記事を生成"""
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M")
        filename = f"{date_str}-market-report.md"
        
        # 市場動向分析
        positive_count = sum(1 for data in market_data.values() if data['change'] > 0)
        negative_count = sum(1 for data in market_data.values() if data['change'] < 0)
        
        if positive_count > negative_count:
            sentiment = "上昇基調"
            sentiment_emoji = "📈"
        elif negative_count > positive_count:
            sentiment = "調整局面"
            sentiment_emoji = "📉"
        else:
            sentiment = "横ばい推移"
            sentiment_emoji = "➡️"
        
        # Front Matter（Jekyll用のメタデータ）
        front_matter = f"""---
layout: post
title: "【市況レポート】{date_str} {time_str} - {sentiment}で推移"
date: {now.strftime("%Y-%m-%d %H:%M:%S +0900")}
categories: [市況, レポート]
tags: [日経平均, 為替, 米国株]
author: AI Reporter
---
"""
        
        # 本文
        content = f"""
## {date_str} {time_str} 更新 - 市場動向レポート

### {sentiment_emoji} 市場概況: {sentiment}

本日の主要市場は**{sentiment}**で推移しています。

### 📊 主要指数の動き
"""
        
        for symbol, data in market_data.items():
            trend = "📈" if data['change'] > 0 else "📉" if data['change'] < 0 else "➡️"
            
            content += f"""
#### {data['name']} {trend}
- **現在値**: {data['price']:,.2f}
- **前日比**: {data['change']:+,.2f} ({data['change_pct']:+.2f}%)
"""
        
        content += f"""

### 🔍 マーケット分析

**本日のポイント:**
- {positive_count}指数が上昇、{negative_count}指数が下落
- 市場の流動性は{'十分' if positive_count >= negative_count else '慎重'}
- 投資家心理は{'楽観的' if positive_count > negative_count else '慎重' if negative_count > positive_count else '中立的'}

### 💡 投資家の皆様へ

**短期的な戦略:**
- 市場の変動性が高いため、リスク管理を最優先に
- 経済指標や企業決算の動向に注意
- ポートフォリオのバランスを定期的にチェック

**中長期的な視点:**
- ファンダメンタルズを重視した銘柄選択
- 分散投資によるリスク軽減
- 定期的な投資スタイルの見直し

### ⚠️ 重要な注意事項
本レポートは情報提供を目的としており、投資助言ではありません。
投資判断は十分な検討の上、自己責任にてお願いいたします。

---
**データ更新時刻**: {time_str}  
**次回更新予定**: 翌営業日

*この記事はAIによって自動生成されています*
"""
        
        # 完全な記事
        full_content = front_matter + content.strip()
        
        return filename, full_content
    
    def publish_post(self, filename, content):
        """記事をファイルに保存"""
        filepath = os.path.join(self.posts_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print(f"✅ 記事を作成: {filename}")
        return filepath
    
    def git_commit_and_push(self, message="Add new market report"):
        """Gitコミット＆プッシュ"""
        try:
            os.chdir(self.repo_path)
            
            # Git初期化（初回のみ）
            if not os.path.exists(os.path.join(self.repo_path, ".git")):
                subprocess.run(["git", "init"], check=True)
                subprocess.run(["git", "branch", "-M", "main"], check=True)
                print("✅ Gitリポジトリを初期化")
            
            # ファイルを追加
            subprocess.run(["git", "add", "."], check=True)
            
            # コミット
            subprocess.run(["git", "commit", "-m", message], check=True)
            print(f"✅ コミット完了: {message}")
            
            # プッシュ（リモートリポジトリが設定されている場合）
            result = subprocess.run(["git", "push", "origin", "main"], 
                                  capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ GitHubにプッシュ完了")
                return True
            else:
                print("⚠️  リモートリポジトリが未設定です")
                print("   以下のコマンドでGitHubリポジトリを設定してください:")
                print(f"   cd {self.repo_path}")
                print("   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git")
                print("   git push -u origin main")
                return False
                
        except subprocess.CalledProcessError as e:
            print(f"❌ Gitエラー: {e}")
            return False
    
    def create_github_actions_workflow(self):
        """GitHub Actions ワークフローを作成"""
        workflow_dir = os.path.join(self.repo_path, ".github", "workflows")
        os.makedirs(workflow_dir, exist_ok=True)
        
        workflow_content = """name: Auto Post Market News

on:
  schedule:
    # 平日 朝9時（JST）= 0時（UTC）
    - cron: '0 0 * * 1-5'
    # 平日 午後3:30（JST）= 6:30（UTC）
    - cron: '30 6 * * 1-5'
  workflow_dispatch:  # 手動実行も可能

jobs:
  generate-and-publish:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout repository
      uses: actions/checkout@v3
    
    - name: Setup Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    
    - name: Install dependencies
      run: |
        pip install yfinance requests
    
    - name: Generate market report
      run: |
        python github_pages_publisher.py --auto
    
    - name: Commit and push
      run: |
        git config --local user.email "action@github.com"
        git config --local user.name "GitHub Action"
        git add .
        git commit -m "Auto-generated market report $(date +'%Y-%m-%d %H:%M')" || exit 0
        git push
"""
        
        workflow_path = os.path.join(workflow_dir, "auto_post.yml")
        with open(workflow_path, 'w', encoding='utf-8') as f:
            f.write(workflow_content.strip())
        
        print("✅ GitHub Actions ワークフローを作成")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='GitHub Pages 自動投稿')
    parser.add_argument('--setup', action='store_true', help='初期セットアップ')
    parser.add_argument('--auto', action='store_true', help='記事生成＆コミット')
    parser.add_argument('--test', action='store_true', help='テスト記事生成のみ')
    
    args = parser.parse_args()
    
    publisher = GitHubPagesPublisher()
    
    if args.setup:
        print("=" * 60)
        print("GitHub Pages サイト初期セットアップ")
        print("=" * 60)
        publisher.setup_github_pages_site()
        publisher.create_github_actions_workflow()
        print("\n✅ セットアップ完了！")
        print("\n次のステップ:")
        print("1. GitHubで新しいリポジトリを作成")
        print("2. 以下のコマンドを実行:")
        print(f"   cd {publisher.repo_path}")
        print("   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git")
        print("   git push -u origin main")
        print("3. GitHub Settings → Pages → Source を 'main' に設定")
        
    elif args.auto or args.test:
        print("=" * 60)
        print("市場レポート生成")
        print("=" * 60)
        
        # 市場データ取得
        market_data = publisher.get_market_data()
        
        if not market_data:
            print("❌ 市場データ取得失敗")
            return
        
        # 記事生成
        filename, content = publisher.generate_markdown_post(market_data)
        
        # 記事保存
        filepath = publisher.publish_post(filename, content)
        
        print(f"\n📄 記事内容:\n{content[:300]}...\n")
        
        if args.auto:
            # Git コミット＆プッシュ
            publisher.git_commit_and_push(f"Add market report: {filename}")
        
        print("✅ 完了")
    
    else:
        parser.print_help()

if __name__ == "__main__":
    main()